The goal is to predict the probability that a certain label is attached to a budget line item. 
Each row in the budget has mostly free-form text features, except for the two columns that are noted as float.


Run:
jupyter notebook notebooks/SchoolBudgeting_CaseStudy.ipynb


Project Organization
------------

  
    ├── README.md   
    ├── data
    │   ├── TestSet.csv
    │   └── TrainingSet.csv
    ├── notebooks
    │   └── SchoolBudgeting_CaseStudy.ipynb
    ├── requirements.txt
    └── src
        ├── __init__.py
        ├── data
        │   └── multilabel.py
        ├── features
        │   └── SparseInteractions.py
        └── models
            └── metrics.py
